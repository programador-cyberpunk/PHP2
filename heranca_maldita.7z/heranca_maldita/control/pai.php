<?php

 class Pai{
public $nome = "Ozzy Osbourne";
public $idade = "500";

 }









?>