      <?php
      ///botei numa classe dados de login do usuario pra poder organizar melhor os pedidos e requisições
      class Dados{
      private $nome;

      private $senha;
      
      private $email;

      private $ordem;
      
      private $setor;
         public function setNome($nm){
            $this->nome = $nm;
         }

         public function setSenha($se){
         $this->senha = $se;
         }

         public function setEmail($em){
         $this->email = $em;
         }

         public function setOrdem($o){
            $this->ordem = $o;
         }

         public function setSetor($set){
            $this->setor = $set;
         }
         
         INSERT INTO usuarios (id, nome, email, senha, setor, ordem) VALUES
   (7, 'Juliana Almeida', 'juliana.almeida@empresa.com', 'senha404', 'Suporte Técnico', 'tecnico'),
   (8, 'Lucas Martins', 'lucas.martins@empresa.com', 'senha505', 'Recursos Humanos', 'usuario'),
   (9, 'Tatiane Rocha', 'tatiane.rocha@empresa.com', 'senha606', 'Suporte Técnico', 'tecnico'),
   (10, 'Felipe Gomes', 'felipe.gomes@empresa.com', 'senha707', 'Marketing', 'usuario'),
   (11, 'Sofia Mendes', 'sofia.mendes@empresa.com', 'senha808', 'Marketing', 'usuario');
      }











?>