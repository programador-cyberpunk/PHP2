<!DOCTYPE html>
<html lang="PT-Br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Vendedor</title>
</head>
<body>
    <form action="../model/inserirVendedor.php"
     method="POST">
       Vendedor<br/>
       <input type="text" 
       name="cxvendedor"/>
       <input type="submit" 
       value="Gravar"/>
    </form>    
</body>
</html>