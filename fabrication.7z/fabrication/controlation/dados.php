<?php
class Dados{
    public $nome;
    public $idade;
    public $email;

    public function exibir(){
        echo $this->nome = "amonimo <br>";
        echo $this->idade = "52 <br>";
        echo $this->email = "naotenhoemail@email.com";
    }
}
?>
