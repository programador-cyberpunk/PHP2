<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watain</title>
    <?php
    include_once "controlation/dados.php";
    ?>
</head>
<body>
    
</body>
</html>

<?php

$cadastro = new Dados;
$cadastro->exibir();
echo "<h1>Dados 2</h1>";
echo $cadastro->nome = "Watain <br>";
echo $cadastro->idade = 28 . "anos";
echo $cadastro->email = "blackmetal@send.com"

?>