<?php
class Caminho{
    public static $usuario = "root";
    public static $senha = "";
    public static $connection = null;

    public static function Conectar(){
        try {
            if(self::$connection == null){
              self::$connection = new PDO('mysql:host=localhost; 
              dbname=loja2000;
              'self::$usuario, self::$senha)
            }
        } catch (Execption $ex) {
            echo 'Mensagem: Deu ruim pro teu lado nigga' .$ex->getMessage();
            die;
        }
        return self::$connection;
    }
    public funcion getConn(){
        return self::Conectar();
        $this->Conectar();
    }
}







?>