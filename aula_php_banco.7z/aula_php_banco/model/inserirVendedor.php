<?php
require_once "../fabrica/conexao.php";

if($_POST['cxvendedor'] != ""){
    $conn = new Caminho;
    $query = 'Insert into vendedor (vendedor) values (:nome)';
    $cadastrar->bindParam(':nome',$_POst['cxvendedor'], PDO::Param_STR);
    $cadastrar=$conn->geConn()->prepare($query);
    $cadastrar->execute();
    if ($cadastrar->rowcount()) {
        echo "Cadastrado com sucesso";
    }else {
        echo "Deu bosta, dados não cadastrados";
    }
}else{
    echo "Deu bosta,dados incompletos";
}





?>